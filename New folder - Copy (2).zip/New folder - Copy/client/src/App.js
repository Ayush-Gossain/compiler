import axios from 'axios'
import './App.css';
import react,{useState} from 'react';

function App() {
  const [code,setCode] = useState("")
  const [lang,setLang] = useState("cpp")
  const [data,setData] = useState("")
  
  const handlesubmit = async()=>{
    const payload ={
      lang,
      code
    }
    try{
      const output=await axios.post("http://localhost:5000/run",payload)
      setData(output.data.data);
      // console.log(output.data.data);
    }catch({response}){
      if(response) {
        const errmsg = response.data.err.stderr;
        setData(errmsg)
        // console.log(errmsg);
      }else{
        setData("no")
      }
    }
    
  }
  return (
    <div className="App">
      <h1>Compiler</h1>
      <div>
        <select value={lang} onChange={(e)=>{setLang(e.target.value)}}>
        <option value="cpp">c++</option>
        <option value="py">python</option>
      </select>
      </div>
      <br/>
      <textarea rows="20" cols="75" value={code} onChange={(e)=>{setCode(e.target.value)}}></textarea>
      <br/>
      <button onClick={handlesubmit}>Submit</button>
      <br/>
      <p>{data}</p>
      
    </div>
  );
}

export default App;
