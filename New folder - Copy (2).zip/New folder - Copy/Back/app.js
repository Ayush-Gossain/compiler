const express = require('express');
const cors = require('cors');
const app = express()
const port = 5000;
const { generateFile} = require('./generateFile')
const { executeCpp} = require('./executeCpp')
const { executePy} = require('./executepy')
app.use(cors())
app.use(express.urlencoded({extended:true}))
app.use(express.json())

app.get('/',(req,res)=>{
    res.send("home")
})
app.post('/run',async (req,res)=>{
    const lang = req.body.lang;
    const code = req.body.code;

    if(code === undefined){
        return res.status(400).json({error:"nocode"})
    }
    const filepath = await generateFile(lang,code)
    let output;
    if (lang == "cpp"){
         output = await executeCpp(filepath)
    }
    else{
         output = await executePy(filepath)
    }
    
    return res.json({filepath,output})
})

app.listen(port,()=>{
    console.log("running on 5000");
})